package com.example.israeli_whist;

import org.checkerframework.checker.units.qual.A;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class Game {


    private int turn;

    private HashMap<String, HashMap<String, ArrayList<Integer>>> hands;
    private ArrayList<Integer> biddings;

    private ArrayList<Integer> current_tricks;

    private ArrayList<Integer> card_played;

    public ArrayList<Integer> getCurrent_tricks() {
        return current_tricks;
    }

    public void setCurrent_tricks(ArrayList<Integer> current_tricks) {
        this.current_tricks = current_tricks;
    }

    public ArrayList<Integer> getCard_played() {
        return card_played;
    }

    public void setCard_played(ArrayList<Integer> card_played) {
        this.card_played = card_played;
    }

    public int getTurn() {
        return turn;
    }

    public ArrayList<Integer> getBiddings() {
        return biddings;
    }

    public void bid(int player, int bid) {
        this.biddings.set(player - 1, bid);
    } // unused

    public void setBiddings(ArrayList<Integer> biddings) {
        this.biddings = biddings;
    }

    public void setTurn(int turn) {
        this.turn = turn;
    }


    public void setHands(HashMap<String, HashMap<String, ArrayList<Integer>>> hands) {
        this.hands = hands;
    }


    public void setHands1(ArrayList<ArrayList<ArrayList<Long>>> hands) { // gets ArrayList<ArrayList<ArrayList<Long>>> and set "hand" with its values
        HashMap<String, HashMap<String, ArrayList<Integer>>> transformedHands = new HashMap<>();

        for (int i = 0; i < 4; i++) {
            HashMap<String, ArrayList<Integer>> playerHands = new HashMap<>();
            ArrayList<ArrayList<Long>> player = hands.get(i + 1);

            for (int j = 0; j < 4; j++) {
                if (player != null) {
                    ArrayList<Integer> cardList = new ArrayList<>();
                    ArrayList<Long> longCardList = player.get(j + 1);
                    for (Long card : longCardList) {
                        cardList.add(card.intValue());
                    }
                    playerHands.put(Integer.toString(j + 1), cardList);
                }
            }
            transformedHands.put(Integer.toString(i + 1), playerHands);
        }
        this.hands = transformedHands;
    }


    public HashMap<String, HashMap<String, ArrayList<Integer>>> getHands() {
        return hands;
    }

    public Game() { //constructor
        this.turn = -1;

        ArrayList<int[]> cards = new ArrayList<>();
        for (int i = 0; i < 52; i++) {
            cards.add(new int[2]);
            cards.get(i)[0] = i % 4 + 1;
            cards.get(i)[1] = i % 13 + 2;
        }
        this.hands = new HashMap();

        for (int j = 1; j <= 4; j++) {
            this.hands.put(Integer.toString(j), new HashMap<>());
            for (int g = 1; g <= 4; g++) {
                this.hands.get(String.valueOf(j)).put(Integer.toString(g), new ArrayList<>());

            }


        }
        Random rand = new Random();
        int random = 0;

        for (int i = 0; i < 52; i++) {
            random = rand.nextInt(cards.size());
            this.hands.get(Integer.toString(i % 4 + 1)).get(Integer.toString(cards.get(random)[0])).add(cards.get(random)[1]);
            cards.remove(random);

        }

        this.biddings = new ArrayList<>();
        this.card_played = new ArrayList<>();
        this.current_tricks = new ArrayList<>();
        for (int i = 1; i <= 4; i++) {
            this.biddings.add(-1);
            this.card_played.add(-1);
            this.current_tricks.add(0);
            for (int g = 1; g <= 4; g++) {
                Collections.sort(this.hands.get(String.valueOf(i)).get(String.valueOf(g)));

            }
        }
    }
}
