package com.example.israeli_whist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;


public class Hand {


    HashMap<Integer, ArrayList<Integer>> hand;



    public Hand(HashMap<String, ArrayList<Integer>> hand) { //constructor
        this.hand = new HashMap<>();
        for (Map.Entry<String, ArrayList<Integer>> entry : hand.entrySet()) {
            int value = Integer.parseInt(entry.getKey());
            this.hand.put(value, entry.getValue());
        }

    }

    public ArrayList<Integer> getSuitCards(int suit) {

        return hand.get(suit);
    }

    public int[] playCard(int index, int requiredSuit, boolean my_turn) { // gets int index, int requiredSuit, boolean my_turn and plays the card it needs to, if it can. returns int[suit, number], unused return

        HashMap<Integer, Integer> correctSuit = new HashMap<>();
        correctSuit.put(1, 3);
        correctSuit.put(2, 4);
        correctSuit.put(3, 2);
        correctSuit.put(4, 1);


        if (my_turn ||hand.get(correctSuit.get(requiredSuit)).size() == 0) {
            for (int i = 1; i <= 4; i++) {
                if (index <= hand.get(i).size()) {
                    int[] card = new int[2];
                    card[0] = i;
                    card[1] = hand.get(i).get(index - 1);
                    hand.get(i).remove(index - 1);
                    return card;
                }
                index -= hand.get(i).size();
            }
        } else {
            for (int i = 1; i <= 4; i++) {
                if (index <= hand.get(i).size()) {
                    if (i != correctSuit.get(requiredSuit)) {
                        return null;
                    }
                    int[] card = new int[2];
                    card[0] = i;
                    card[1] = hand.get(i).get(index - 1);
                    hand.get(i).remove(index - 1);
                    return card;
                }
                index -= hand.get(i).size();
            }

        }
        return null;
    }

    public boolean canplayCard(int index, int requiredSuit, boolean my_turn) { // same as playCard but returns true if you can play the card and false if you cant

        HashMap<Integer, Integer> correctSuit = new HashMap<>();
        correctSuit.put(1, 3);
        correctSuit.put(2, 4);
        correctSuit.put(3, 2);
        correctSuit.put(4, 1);


        if (my_turn || hand.get(correctSuit.get(requiredSuit)).size() == 0) {

            return true;


        } else {
            for (int i = 1; i <= 4; i++) {
                if (index <= hand.get(i).size()) {
                    if (i != correctSuit.get(requiredSuit)) {
                        return false;
                    }

                    return true;
                }
                index -= hand.get(i).size();
            }

        }
        return false;
    }

    public ArrayList<Integer> getCards() {

        ArrayList<Integer> cards = new ArrayList<>();

        for (int i = 1; i <= 4; i++) {
            int size = hand.get(i).size();
            for (int j = 0; j < size; j++) {
                cards.add(i - 1 + (hand.get(i).get(j) - 2) * 4); //suit
            }
        }
        return cards;
    }


}
