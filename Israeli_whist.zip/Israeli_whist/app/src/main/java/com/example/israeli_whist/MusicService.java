package com.example.israeli_whist;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;

import androidx.annotation.Nullable;

public class MusicService extends Service {
    private MediaPlayer player;

    @Nullable
    @Override

    public IBinder onBind(Intent intent) {
        return null;
    }


    @Override
    public void onCreate() { //create the playermedia with the correct sound and volium
        super.onCreate();


        player = MediaPlayer.create(this, R.raw.sound);


        player.setVolume(1.0f, 1.0f);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) { //plays the sound
        player.start();
        return super.onStartCommand(intent, flags, startId);
    }


    @Override
    public void onDestroy() {
        player.stop();
    } //stops the sound
}