package com.example.israeli_whist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;

public class GameStatsActivity extends AppCompatActivity {

    private TextView[] textp;
    private ArrayList<Integer> arr;
    private String[] emails;

    private Button btnNext;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_stats);

        btnNext = findViewById(R.id.btnNext);


        Intent intent = getIntent();

        textp = new TextView[4];

        textp[0] = findViewById(R.id.txtPlayer1);
        textp[1] = findViewById(R.id.txtPlayer2);
        textp[2] = findViewById(R.id.txtPlayer3);
        textp[3] = findViewById(R.id.txtPlayer4);

        emails = new String[4];
        emails[0] = intent.getStringExtra("1");
        emails[1] = intent.getStringExtra("2");
        emails[2] = intent.getStringExtra("3");
        emails[3] = intent.getStringExtra("4");

        arr = new ArrayList<>();
        arr.add(intent.getIntExtra(emails[0], 0));
        arr.add(intent.getIntExtra(emails[1], 0));
        arr.add(intent.getIntExtra(emails[2], 0));
        arr.add(intent.getIntExtra(emails[3], 0));

        textp[0].setText(emails[0] + ": " + arr.get(0));
        textp[1].setText(emails[1] + ": " + arr.get(1));
        textp[2].setText(emails[2] + ": " + arr.get(2));
        textp[3].setText(emails[3] + ": " + arr.get(3));


        btnNext.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent i = new Intent(GameStatsActivity.this, MainActivity.class);
                startActivity(i);

            }
        });





    }
}