package com.example.israeli_whist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class JoinRoom extends AppCompatActivity {

    private FirebaseAuth auth;
    private TextView[] players_text;
    private TextView text_id;

    private ValueEventListener listener;
    private ValueEventListener listener1;

    private ArrayList<String> users;

    private Intent musicIntent;

    private Button btnBack;
    private DatabaseReference roomRef;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_room);

        musicIntent = new Intent(this, MusicService.class);
        startMusic();


        Intent intent = getIntent();
        String id = intent.getStringExtra("id");

        FirebaseApp.initializeApp(this);

        auth = FirebaseAuth.getInstance();
        players_text = new TextView[4];
        players_text[0] = findViewById(R.id.textPlayer1);
        players_text[1] = findViewById(R.id.textPlayer2);
        players_text[2] = findViewById(R.id.textPlayer3);
        players_text[3] = findViewById(R.id.textPlayer4);
        text_id = findViewById(R.id.textId);

        FirebaseDatabase database = FirebaseDatabase.getInstance("https://israeli-whist-aae67-default-rtdb.europe-west1.firebasedatabase.app/");
        roomRef = database.getReference("Rooms").child(id);


        btnBack = findViewById(R.id.btnBack1);


        text_id.setText("id: " + id);

        roomRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                DataSnapshot usersSnapshot = dataSnapshot.child("users");

                ArrayList<String> users = (ArrayList<String>) usersSnapshot.getValue();

                for (int i = 0; i < users.size(); i++) {
                    players_text[i].setText("player " + (i + 1) + ": " + users.get(i));
                }


                Room room = new Room(id, "");
                room.setUsers(users);
                roomRef.child("users").addValueEventListener(listener);
                roomRef.child("game").child("turn").addValueEventListener(listener1);
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });




        listener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                users = (ArrayList<String>) dataSnapshot.getValue();

                for (int i = 1; i < users.size(); i++) {
                    players_text[i].setText("player " + (i + 1) + ": " + users.get(i));
                }
                for (int i = users.size(); i < 4; i++) {
                    players_text[i].setText("player " + (i + 1) + ": ");
                }

                startMusic();


            }

            @Override
            public void onCancelled(DatabaseError error) {

            }
        };

        listener1 = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                int value = dataSnapshot.getValue(Integer.class);

                if (value == 1) {
                    roomRef.child("users").removeEventListener(listener);
                    roomRef.child("game").child("turn").removeEventListener(listener1);


                    Intent i = new Intent(JoinRoom.this, GameActivity.class);
                    i.putExtra("id", id);
                    i.putExtra("player_num", users.indexOf(auth.getCurrentUser().getEmail().substring(0, auth.getCurrentUser().getEmail().length() - 10)) + 1);
                    startActivity(i);
                }

            }



            @Override
            public void onCancelled(DatabaseError error) {

            }
        };

        btnBack.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                DatabaseReference usersRef = database.getReference("Rooms").child(id).child("users");
                usersRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        ArrayList<String> arr = (ArrayList<String>) dataSnapshot.getValue();
                        auth = FirebaseAuth.getInstance();

                        arr.remove(arr.indexOf(auth.getCurrentUser().getEmail().substring(0, auth.getCurrentUser().getEmail().length() - 10)));
                        usersRef.setValue(arr);

                        Intent i = new Intent(JoinRoom.this, MainActivity.class);
                        startActivity(i);

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }

                });
            }
        });
    }

    public void startMusic() {
        startService(musicIntent);
    } // plays sound
}







