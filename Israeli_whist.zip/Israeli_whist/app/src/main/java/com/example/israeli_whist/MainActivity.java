package com.example.israeli_whist;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {


    private  Button how_to_play;
    private Button create_room;
    private Button join_room;
    private Button logout;
    private FirebaseAuth auth;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        how_to_play = findViewById(R.id.btnHowToPlay);
        create_room = findViewById(R.id.btnCreateRoom);
        join_room = findViewById(R.id.btnJoinRoom);
        logout = findViewById(R.id.btnLogout);



        create_room.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent i = new Intent(MainActivity.this, CreateRoom.class);
                startActivity(i);

            }
        });
        how_to_play.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent i = new Intent(MainActivity.this, How_to_play.class);
                startActivity(i);

            }
        });
        join_room.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                showDialog();
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {


                auth = FirebaseAuth.getInstance();

                auth.signOut();
                Intent i = new Intent(MainActivity.this, Login.class);
                startActivity(i);

            }
        });
    }

    private void showDialog() { // shows a dialog that the user will enter into it the id of the room that he wants to join to and if its corect he will be moved to that room and if not he will not
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter your text");

        final EditText input = new EditText(this);
        builder.setView(input);

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                FirebaseDatabase database = FirebaseDatabase.getInstance("https://israeli-whist-aae67-default-rtdb.europe-west1.firebasedatabase.app/");
                DatabaseReference roomsRef = database.getReference("Rooms");
                String userInput = input.getText().toString();


                roomsRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        HashMap<String, HashMap<String, ArrayList<String>>> map = (HashMap<String, HashMap<String, ArrayList<String>>>)dataSnapshot.getValue();
                        auth = FirebaseAuth.getInstance();

                        if (map.containsKey(userInput)){


                            map.get(userInput).get("users").add(auth.getCurrentUser().getEmail().substring(0, auth.getCurrentUser().getEmail().length() - 10));
                            ArrayList<String> users = map.get(userInput).get("users");

                            Map<String, Object> updates = new HashMap<>();
                            updates.put("users", users);
                            roomsRef.child(userInput).updateChildren(updates);


                            Intent i = new Intent(MainActivity.this, JoinRoom.class);
                            i.putExtra("id", userInput);
                            startActivity(i);
                            }
                        }





                    @Override
                    public void onCancelled(DatabaseError error) {

                    }
                });




            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                Toast.makeText(MainActivity.this, "Cancelled", Toast.LENGTH_SHORT).show();
                dialog.cancel();
            }
        });

        builder.show();
    }

    @Override
    public void onBackPressed() { //prevent from clicking on the back button of the phone
    }
}




