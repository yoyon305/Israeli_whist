package com.example.israeli_whist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;

public class How_to_play extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_how_to_play);

        Button back = findViewById(R.id.btnBack);

        back.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent i = new Intent(How_to_play.this, MainActivity.class);
                startActivity(i);

            }
        });

    }

}