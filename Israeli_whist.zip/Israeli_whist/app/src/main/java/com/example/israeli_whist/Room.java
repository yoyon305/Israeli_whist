package com.example.israeli_whist;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class Room {

    private String id;
    private Game game;
    private ArrayList<String> users;

    public Room() {

    }





    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Game getGame() {
        return game;
    }

    public void setGame(Game game) {
        this.game = game;
    }


    public ArrayList<String> getUsers() {
        return users;
    }

    public void setUsers(ArrayList<String> users) {
        this.users = users;
    }

    public void addUser(String user) {
        users.add(user);
    }

    public void removeUser(String user) {
        this.users.remove(user);
    }

    public Room(String user) {//empty constructor

        this.game = new Game();
        this.users = new ArrayList<>();
        this.users.add(user);
    }

    public Room(String id, String user) {//constructor

        HashMap<Integer, ArrayList<Integer>> cards = new HashMap<>();

        for (int k = 1; k <= 4; k++) {
            cards.put(k, new ArrayList<Integer>());
        }

        for (int i = 1; i <= 4; i++) {
            for (int j = 0; j < 13; j++) {
                cards.get(i).add(j);
            }
        }
        int[][][] hands = new int[4][13][2];
        Random rand = new Random();
        int suit = rand.nextInt(4) + 1;
        int number;

        for (int b = 0; b < 4; b++) {
            for (int c = 0; c < 13; c++) {

                while ( cards.get(suit).size() == 0) {
                    suit = rand.nextInt(4) + 1;
                }

                number = rand.nextInt(cards.get(suit).size());
                hands[b][c][0] = suit;
                hands[b][c][1] =  cards.get(suit).get(number);

                cards.get(suit).remove(number);
                suit = rand.nextInt(4) + 1;
            }

        }

        this.id = id;

    }
}
