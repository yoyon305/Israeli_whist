package com.example.israeli_whist;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Firebase;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseError;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Random;

public class GameActivity extends AppCompatActivity {


    private int number;

    private ConstraintLayout layout;

    private ArrayList<ImageView> cards; //player 1 hand images

    private Hand hand; //player 1 hand

    private String[] suits; // spades, hearts, diamonds, clubs

    private String[] numbers;

    private ArrayList<Integer> sortedCards;

    private int clicked_card;

    private boolean relevant_click;

    private int last_card_played_number;
    private TextView bidding_number, bid_num_p1, bid_num_p2, bid_num_p3, bid_num_p4;

    private Button btnSpade, btnHeart, btnClub, btnDiamond, btnNt;
    private Button btnBid, btnPass, btnPlus, btnMinus;
    private ValueEventListener listener;
    private ChildEventListener listener1;
    private ValueEventListener listener2;
    private ValueEventListener listener3;
    private int phase;

    private ImageView[] cards_images;

    private double card_number;
    private int[] biddings; //player, (number, suit)
    private long currentBid; //number, suit
    private long highestBid; //number, suit
    private Room room;
    private Game game;
    private long turn;
    private int turns_after_last_bid;
    private Context mContext;
    private long suit;

    private int turns_after_bid;
    private long bidding_sum;
    private String[] suits1;

    private int needed_suit;

    private int cards_played_counter;
    private ArrayList<Integer> current_tricks;

    private ImageView symbol_in_the_center;
    private boolean clicks_not_allowed;

    private Intent musicIntent;

    private long turn_saver;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);


        musicIntent = new Intent(this, MusicService.class);


        bidding_number = new TextView(this);
        bid_num_p1 = new TextView(this);
        bid_num_p2 = new TextView(this);
        bid_num_p3 = new TextView(this);
        bid_num_p4 = new TextView(this);
        btnPlus = new Button(this);
        btnMinus = new Button(this);
        btnSpade = new Button(this);
        btnHeart = new Button(this);
        btnDiamond = new Button(this);
        btnClub = new Button(this);
        btnNt = new Button(this);
        btnBid = new Button(this);
        btnPass = new Button(this);

        currentBid = 1;

        biddings = new int[4];

        phase = 0;

        needed_suit = 0;

        clicks_not_allowed = false;

        cards_images = new ImageView[3];

        cards_images[0] = new ImageView(this);
        cards_images[1] = new ImageView(this);
        cards_images[2] = new ImageView(this);


        symbol_in_the_center = new ImageView(this);



        cards_played_counter = 0;
        current_tricks = new ArrayList<>();
        current_tricks.add(0);
        current_tricks.add(0);
        current_tricks.add(0);
        current_tricks.add(0);


        layout = findViewById(R.id.layout);


        suits = new String[]{"spades", "hearts", "clubs", "diamonds"};
        numbers = new String[]{"two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "jack", "queen", "king", "ace"};
        suits1 = new String[]{"club", "diamond", "heart", "spade", "NT"};


        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);


        DisplayMetrics display = getResources().getDisplayMetrics();
        int height = display.heightPixels;
        int width = display.widthPixels;
        int usableWidth = width - width / 4;

        clicked_card = -1;
        relevant_click = false;
        last_card_played_number = -1;

        Intent i = getIntent();
        String id = i.getStringExtra("id");
        int player_num = i.getIntExtra("player_num", 0);


        turn = 1;
        highestBid = -1;
        mContext = this;

        turn_saver = 1;

        FirebaseDatabase database = FirebaseDatabase.getInstance("https://israeli-whist-aae67-default-rtdb.europe-west1.firebasedatabase.app/");
        DatabaseReference roomRef = database.getReference("Rooms").child(id);


        listener2 = new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) { //initialize the basic stuff

                DataSnapshot usersSnapshot = dataSnapshot.child("users");

                ArrayList<String> users = (ArrayList<String>) usersSnapshot.getValue();
                DataSnapshot handSnapshot = dataSnapshot.child("game").child("hands");
                room = new Room(id, "");
                room.setUsers(users);
                game = new Game();
                ArrayList<ArrayList<ArrayList<Long>>> gameMap = (ArrayList<ArrayList<ArrayList<Long>>>) handSnapshot.getValue();

                game.setHands1(gameMap);
                room.setGame(game);
                hand = new Hand(game.getHands().get(String.valueOf(player_num))); //player 1
                sortedCards = hand.getCards();
                cards = new ArrayList<>();
                for (int j = 0; j < 13; j++) {
                    cards.add(new ImageView(mContext));

                    String card_name = numbers[sortedCards.get(j) / 4] + "_of_" + suits[sortedCards.get(j) % 4];
                    int resourceId = getResources().getIdentifier(card_name, "drawable", getPackageName());
                    cards.get(j).setImageResource(resourceId);


                    switch ((sortedCards.get(j) % 4)) {
                        case 0:
                            sortedCards.set(j, sortedCards.get(j) + 3);
                            break;
                        case 1:
                            sortedCards.set(j, sortedCards.get(j) + 1);
                            break;
                        case 2:
                            sortedCards.set(j, sortedCards.get(j) - 2);
                            break;
                        case 3:
                            sortedCards.set(j, sortedCards.get(j) - 2);
                            break;
                    }

                }

                number = 13;


                update_game(cards, layout, number, 1);
                update_game(null, layout, 13, 3);
                update_game(null, layout, 13, 2);
                update_game(null, layout, 13, 4);

                layout.addView(cards_images[0]);
                layout.addView(cards_images[1]);
                layout.addView(cards_images[2]);
                layout.addView(symbol_in_the_center);


                ConstraintLayout.LayoutParams params4 = new ConstraintLayout.LayoutParams((int) (width / 3 * 0.6887), width / 3);

                cards_images[0].setLayoutParams(params4);
                cards_images[1].setLayoutParams(params4);
                cards_images[2].setLayoutParams(params4);


                ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams((int) (width / 4), height / 14);
                btnPass.setX((float) (width / 2 - 0.5 * params.width - params.width * 0.6));
                btnPass.setY((float) (height / 2));
                btnPass.setText("pass");
                btnPass.setBackgroundColor(Color.rgb(220, 220, 220));
                btnPass.setLayoutParams(params);
                btnPass.setTextSize(24);


                btnBid.setX((float) (width / 2 - 0.5 * params.width + params.width * 0.6));
                btnBid.setY((float) (height / 2));
                btnBid.setText("bid");
                btnBid.setBackgroundColor(Color.rgb(220, 220, 220));
                btnBid.setLayoutParams(params);
                btnBid.setTextSize(24);

                bidding_number.setX((float) (width / 2 - 0.5 * params.width));
                bidding_number.setY((float) (height / 2.4));
                bidding_number.setText(Long.toString(5 + ((currentBid - 1) / 5)));
                bidding_number.setBackgroundColor(Color.rgb(220, 220, 220));
                bidding_number.setTextColor(Color.BLACK);
                bidding_number.setTextSize(24);
                bidding_number.setLayoutParams(params);
                bidding_number.setGravity(Gravity.CENTER);

                params = new ConstraintLayout.LayoutParams((int) (width / 8), height / 17);

                btnPlus.setX((float) (width - (width / 3.5) - 0.5 * params.width));
                btnPlus.setY((float) (height / 2.4 + ((height / 14 - height / 17) / 2)));
                btnPlus.setText("+");
                btnPlus.setBackgroundColor(Color.rgb(220, 220, 220));
                btnPlus.setLayoutParams(params);
                btnPlus.setTextSize(20);


                btnMinus.setX((float) (width / 3.5 - 0.5 * params.width));
                btnMinus.setY((float) (height / 2.4 + ((height / 14 - height / 17) / 2)));
                btnMinus.setText("-");
                btnMinus.setBackgroundColor(Color.rgb(220, 220, 220));
                btnMinus.setLayoutParams(params);
                btnMinus.setTextSize(24);


                btnSpade.setX((float) (width / 2 - 0.5 * params.width - (width / 2 - 0.5 * params.width - (width / 3.5 - 0.5 * params.width)) / 2));
                btnSpade.setY((float) (height / 2 + (height / 2 - height / 2.4) * 2 + 0.25 * params.height));
                btnSpade.setBackgroundResource(R.drawable.spade);
                btnSpade.setLayoutParams(params);

                btnDiamond.setX((float) (width / 2 - 0.5 * params.width));
                btnDiamond.setY((float) (height / 2 + (height / 2 - height / 2.4) + 0.25 * params.height));
                btnDiamond.setBackgroundResource(R.drawable.diamond);
                btnDiamond.setLayoutParams(params);


                btnClub.setX((float) (width / 3.5 - 0.5 * params.width));
                btnClub.setY((float) (height / 2 + (height / 2 - height / 2.4) + 0.25 * params.height));
                btnClub.setBackgroundResource(R.drawable.club);
                btnClub.setLayoutParams(params);

                btnHeart.setX((float) (width - (width / 3.5) - 0.5 * params.width));
                btnHeart.setY((float) (height / 2 + (height / 2 - height / 2.4) + 0.25 * params.height));
                btnHeart.setBackgroundResource(R.drawable.heart);
                btnHeart.setLayoutParams(params);

                btnNt.setX((float) (width / 2 - 0.5 * params.width + (width / 2 - 0.5 * params.width - (width / 3.5 - 0.5 * params.width)) / 2));
                btnNt.setY((float) (height / 2 + (height / 2 - height / 2.4) * 2 + 0.25 * params.height));
                btnNt.setLayoutParams(params);
                btnNt.setTextSize(14);
                btnNt.setText("NT");
                btnNt.setBackgroundColor(Color.rgb(20, 80, 13));


                bid_num_p1.setText("");
                bid_num_p1.setTextSize(18);
                bid_num_p1.setX((float) (width / 2 - 0.5 * params.width));
                bid_num_p1.setY((float) (height / 3));
                bid_num_p1.setLayoutParams(params);
                bid_num_p1.setTextColor(Color.BLACK);

                bid_num_p2.setText("");
                bid_num_p2.setTextSize(18);
                bid_num_p2.setX((float) (width / 4 - 0.5 * params.width));
                bid_num_p2.setY((float) (height / 4.5));
                bid_num_p2.setLayoutParams(params);
                bid_num_p2.setTextColor(Color.BLACK);

                bid_num_p3.setText("");
                bid_num_p3.setTextSize(18);
                bid_num_p3.setX((float) (width / 2 - 0.5 * params.width));
                bid_num_p3.setY((float) (height / 10));
                bid_num_p3.setLayoutParams(params);
                bid_num_p3.setTextColor(Color.BLACK);

                bid_num_p4.setText("");
                bid_num_p4.setTextSize(18);
                bid_num_p4.setX((float) (width - (width / 4) - params.width / 2));
                bid_num_p4.setY((float) (height / 4.5));
                bid_num_p4.setLayoutParams(params);
                bid_num_p4.setTextColor(Color.BLACK);


                layout.addView(btnBid);
                layout.addView(bidding_number);
                layout.addView(btnMinus);
                layout.addView(btnPlus);
                layout.addView(btnClub);
                layout.addView(btnSpade);
                layout.addView(btnDiamond);
                layout.addView(btnHeart);
                layout.addView(btnNt);
                layout.addView(btnPass);
                layout.addView(bid_num_p1);
                layout.addView(bid_num_p2);
                layout.addView(bid_num_p3);
                layout.addView(bid_num_p4);



                roomRef.child("game").child("turn").addValueEventListener(listener);

                roomRef.child("game").child("biddings").addChildEventListener(listener1);

                roomRef.child("game").child("card_played").addValueEventListener(listener3);


            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                System.out.println("f");
            }
        };
        roomRef.addListenerForSingleValueEvent(listener2);


        listener = new ValueEventListener() { //when turn passes updates the turn and play a sound
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                room.getGame().setTurn(Math.toIntExact((long) dataSnapshot.getValue()));
                turn = (long) dataSnapshot.getValue();

                //if (cards_played_counter != 0){
                //    turn_saver = turn;
                //}


                startMusic();

            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        };


        listener1 = new ChildEventListener() { //when biddings changes, it understands which phase of the biddings the game is and updates the screen, turn, biddings... accordingly. it also changes phases if needed
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                HashMap<Integer, Integer> turns = new HashMap<>();
                turns.put(1, 4);
                turns.put(2, 1);
                turns.put(3, 2);
                turns.put(4, 3);


                int correct_turn = (int) turn;


                for (int i = 0; i < player_num; i++) {
                    correct_turn = turns.get(correct_turn);
                }


                if (phase == 1) {

                    TextView bidTextView;
                    if ((int) ((long) snapshot.getValue()) != -1) {
                        biddings[correct_turn - 1] = (int) ((long) snapshot.getValue());
                    }
                    if (turns_after_bid >= 4) {
                        bidding_sum += Long.parseLong(snapshot.getValue().toString());

                        String[] symbols = new String[]{"♣", "♦", "♥", "♠", " NT"};
                        int symbol = (int) suit;

                        switch (correct_turn) {
                            case 1:
                                bidTextView = bid_num_p1;

                                break;
                            case 2:
                                bidTextView = bid_num_p2;

                                break;
                            case 3:
                                bidTextView = bid_num_p3;

                                break;
                            case 4:
                                bidTextView = bid_num_p4;

                                break;
                            default:

                                return;
                        }

                        bidTextView.setText(String.valueOf(snapshot.getValue()) + "" + symbols[symbol]);

                    }




                    turns_after_bid++;

                    if (turns_after_bid == 7) {


                        Handler handler = new Handler();


                        clicks_not_allowed = true;
                        btnBid.setClickable(false);

                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {

                                phase = 2;


                                String card_name = suits1[(int) suit];

                                int resourceId = getResources().getIdentifier(card_name, "drawable", getPackageName());


                                ConstraintLayout.LayoutParams params5 = new ConstraintLayout.LayoutParams((int) (width / 3 * 0.6887 / 2.7), (int) (width / 3 * 0.6887 / 2.7));

                                symbol_in_the_center.setImageResource(resourceId);
                                symbol_in_the_center.setLayoutParams(params5);
                                symbol_in_the_center.setX(width / 2 - params5.width / 2);
                                symbol_in_the_center.setY(height / 2 - params5.width / 2);


                                layout.removeView(btnBid);
                                layout.removeView(bidding_number);
                                layout.removeView(btnMinus);
                                layout.removeView(btnPlus);


                                bid_num_p1.setTextSize(15);
                                bid_num_p2.setTextSize(15);
                                bid_num_p3.setTextSize(15);
                                bid_num_p4.setTextSize(15);

                                bid_num_p1.setText("0/" + biddings[0]);
                                bid_num_p2.setText("0/" + biddings[1]);
                                bid_num_p3.setText("0/" + biddings[2]);
                                bid_num_p4.setText("0/" + biddings[3]);


                                bid_num_p1.setX(width / 15);
                                bid_num_p1.setY((int) (height / 2 + 0.5 * width / 3 + width / 3 / 2));

                                bid_num_p2.setX(width / 15);
                                bid_num_p2.setY((int) ((height - (height / 2 + 0.5 * width / 3)) - cards_images[0].getHeight() * 1.5 - cards_images[0].getHeight() * 0.2));

                                bid_num_p3.setX(width / 2 - bid_num_p3.getWidth() / 2);
                                bid_num_p3.setY((int) ((height - (height / 2 + 0.5 * width / 3)) - cards_images[0].getHeight() * 1.5 - cards_images[0].getHeight() * 0.4));

                                bid_num_p4.setX((int) (width / 2 + cards_images[0].getWidth() * 0.7));
                                bid_num_p4.setY((int) ((height - (height / 2 + 0.5 * width / 3)) - cards_images[0].getHeight() * 1.5 - cards_images[0].getHeight() * 0.2));


                                clicks_not_allowed = false;
                            }
                        }, 2000);


                    } else {
                    }
                } else if (highestBid < Long.parseLong(snapshot.getValue().toString()) && phase == 0) {

                    highestBid = (long) snapshot.getValue();
                    turns_after_last_bid = 1;
                    suit = (highestBid - 1) % 5;

                    TextView bidTextView;

                    String[] symbols = new String[]{"♣", "♦", "♥", "♠", " NT"};
                    int symbol = (int) suit;

                    switch (correct_turn) {
                        case 1:
                            bidTextView = bid_num_p1;

                            break;
                        case 2:
                            bidTextView = bid_num_p2;

                            break;
                        case 3:
                            bidTextView = bid_num_p3;

                            break;
                        case 4:
                            bidTextView = bid_num_p4;

                            break;
                        default:

                            return;
                    }


                    bidTextView.setText(String.valueOf(5 + ((highestBid - 1) / 5)) + "" + symbols[symbol]);

                } else if (phase == 0) {
                    turns_after_last_bid++;
                    switch (correct_turn) {
                        case 1:
                            bid_num_p1.setText("pass");

                            break;
                        case 2:
                            bid_num_p2.setText("pass");

                            break;
                        case 3:
                            bid_num_p3.setText("pass");

                            break;
                        case 4:
                            bid_num_p4.setText("pass");

                            break;
                    }
                } if (turns_after_last_bid >= 4) {
                    if (highestBid == -1) {
                        if (turns_after_last_bid == 4) {

                            Intent i = new Intent(GameActivity.this, GameStatsActivity.class);

                            i.putExtra(String.valueOf(room.getUsers().get(0)), 0);
                            i.putExtra(String.valueOf(room.getUsers().get(1)), 0);
                            i.putExtra(String.valueOf(room.getUsers().get(2)), 0);
                            i.putExtra(String.valueOf(room.getUsers().get(3)), 0);

                            i.putExtra("1", room.getUsers().get(0));
                            i.putExtra("2", room.getUsers().get(1));
                            i.putExtra("3", room.getUsers().get(2));
                            i.putExtra("4", room.getUsers().get(3));

                            startActivity(i);
                        }
                    } else {


                        Handler handler = new Handler();


                        clicks_not_allowed = true;
                        btnPass.setClickable(false);
                        btnBid.setClickable(false);


                        Runnable runnable = new Runnable() {
                            @Override
                            public void run() {

                                ConstraintLayout.LayoutParams params1 = new ConstraintLayout.LayoutParams(0, 0);

                                turns_after_bid = 0;
                                turns_after_last_bid = 0;

                                phase = 1;

                                if (highestBid == 5) {
                                    turns_after_bid++;
                                }



                                suit = (highestBid - 1) % 5;

                                bidding_sum = (5 + ((highestBid - 1) / 5));

                                btnClub.setLayoutParams(params1);
                                btnSpade.setLayoutParams(params1);
                                btnNt.setLayoutParams(params1);
                                btnHeart.setLayoutParams(params1);
                                btnDiamond.setLayoutParams(params1);
                                btnPass.setLayoutParams(params1);

                                currentBid = 0;
                                bidding_number.setText(Long.toString(currentBid));

                                layout.removeView(btnClub);
                                btnClub = null;
                                btnDiamond = null;
                                btnHeart = null;
                                btnSpade = null;
                                btnNt = null;
                                btnPass = null;

                                bid_num_p1.setText("");

                                bid_num_p2.setText("");

                                bid_num_p3.setText("");

                                bid_num_p4.setText("");


                                turn = turn % 4 + 1;


                                roomRef.child("game").child("turn").setValue(turn);


                                int correct_turn = (int) turn;


                                for (int i = 0; i < player_num; i++) {
                                    correct_turn = turns.get(correct_turn);
                                }

                                if (player_num == 1) {
                                    for (int i = 0; i < 4; i++) {
                                        if (correct_turn - 1 == i) {
                                            roomRef.child("game").child("biddings").child(String.valueOf(i)).setValue(5 + ((highestBid - 1) / 5));
                                            biddings[correct_turn - 1] = (int) (5 + ((highestBid - 1) / 5));
                                        } else {
                                            roomRef.child("game").child("biddings").child(String.valueOf(i)).setValue(-1);
                                        }
                                    }
                                }

                                String[] symbols = new String[]{"♣", "♦", "♥", "♠", " NT"};
                                int symbol = (int) suit;

                                switch (correct_turn) {
                                    case 1:
                                        bid_num_p1.setText(String.valueOf(5 + ((highestBid - 1) / 5)) + "" + symbols[symbol]);

                                        break;
                                    case 2:

                                        bid_num_p2.setText(String.valueOf(5 + ((highestBid - 1) / 5)) + "" + symbols[symbol]);
                                        break;
                                    case 3:
                                        bid_num_p3.setText(String.valueOf(5 + ((highestBid - 1) / 5)) + "" + symbols[symbol]);

                                        break;
                                    case 4:
                                        bid_num_p4.setText(String.valueOf(5 + ((highestBid - 1) / 5)) + "" + symbols[symbol]);

                                        break;
                                }

                                layout.invalidate();
                                clicks_not_allowed = true;
                                btnBid.setClickable(true);
                            }
                        };


                        handler.postDelayed(runnable, 2000);

                    }

                }


            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        };


        listener3 = new ValueEventListener() {//if cards played changes, it updates the ui and if all players played a card it calculates the winner and updates the game accordingly


            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                turn_saver = turn;


                int targets_index = (int) (turn_saver - player_num + 4) % 4 + 1;


                int realPlayerNumber = (player_num + targets_index - 1) % 4;


                if (realPlayerNumber == 0) {
                    realPlayerNumber = 4;
                }


                if ((int) ((long) (snapshot.child(String.valueOf(realPlayerNumber - 1)).getValue())) == -1){
                    return;
                }

                cards_played_counter++;



                if (cards_played_counter == 1) {
                    needed_suit = ((int) ((long) (snapshot.child(String.valueOf(realPlayerNumber - 1)).getValue()))) % 4;
                }


                if (turn != player_num && ((int) ((long) snapshot.child(String.valueOf(realPlayerNumber - 1)).getValue())) != -1) {


                    double x = 0;
                    double y = 0;

                    String card_name = numbers[(int) ((long) snapshot.child(String.valueOf(realPlayerNumber - 1)).getValue()) / 4] + "_of_" + suits1[((int) ((long) snapshot.child(String.valueOf(realPlayerNumber - 1)).getValue())) % 4] + "s";

                    switch (targets_index) {
                        case 2:
                            x = (int) (width / 2 - cards_images[0].getWidth() * 1.4);
                            y = (int) ((height - (height / 2 + 0.5 * width / 3)) - cards_images[0].getHeight() * 1.5 + (int) (height / 2 + 0.5 * width / 3)) / 2;
                            break;
                        case 3:
                            x = (int) (width / 2 - 0.5 * width / 3 * 0.6887);
                            y = (int) (height - (height / 2 + 0.5 * width / 3)) - cards_images[0].getHeight() * 1.5;
                            break;
                        case 4:
                            x = (int) (width / 2 + cards_images[0].getWidth() * 0.4);
                            y = (int) ((height - (height / 2 + 0.5 * width / 3)) - cards_images[0].getHeight() * 1.5 + (int) (height / 2 + 0.5 * width / 3)) / 2;
                            break;
                    }


                    int resourceId = getResources().getIdentifier(card_name, "drawable", getPackageName());
                    cards_images[targets_index - 2].setImageResource(resourceId);
                    cards_images[targets_index - 2].setVisibility(View.VISIBLE);


                    cards_images[targets_index - 2].setX((int) x);
                    cards_images[targets_index - 2].setY((int) y);



                    int cards_sum = 0;
                    int[] cards_saver = new int[4];

                    for (int i = 0; i < 4; i++) {

                        if (cards_played_counter == 1) {

                            cards_saver[i] = sortedCards.size() - 1;

                        } else if (targets_index > 1 && targets_index < (targets_index - cards_played_counter + 1)) {

                            cards_saver[i] = sortedCards.size() - 1;

                        } else {
                            cards_saver[i] = sortedCards.size();
                        }

                    }

                    for (int j = 0; j < turn - 1; j++) {
                        cards_sum += cards_saver[(5 - player_num + j) % 4];
                    }

                    for (int g = cards_sum - 1; g < cards_sum + cards_saver[(int) (4 - player_num + turn) % 4] - 1; g++) {


                    }


                    if (cards_played_counter == 1) {



                    } else if (targets_index > 1 && targets_index < (targets_index - cards_played_counter + 1)) {


                    } else {

                    }

                }

                if (cards_played_counter == 4) {




                    clicks_not_allowed = true;

                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            int winner = round_winner((int) turn_saver, (int) suit + 1, snapshot, layout, last_card_played_number);

                            if (player_num == 1) {
                                roomRef.child("game").child("current_tricks").child(String.valueOf(winner - 1)).setValue(current_tricks.get(winner - 1) + 1)
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    current_tricks.set(winner - 1, current_tricks.get(winner - 1) + 1);


                                                    switch (((winner - 1) + (5 - player_num)) % 4 + 1) {
                                                        case 1:
                                                            bid_num_p1.setText(String.valueOf(current_tricks.get(winner - 1)) + "/" + String.valueOf(biddings[((winner - 1) + (5 - player_num)) % 4]));
                                                            break;
                                                        case 2:
                                                            bid_num_p2.setText(String.valueOf(current_tricks.get(winner - 1)) + "/" + String.valueOf(biddings[((winner - 1) + (5 - player_num)) % 4]));
                                                            break;
                                                        case 3:
                                                            bid_num_p3.setText(String.valueOf(current_tricks.get(winner - 1)) + "/" + String.valueOf(biddings[((winner - 1) + (5 - player_num)) % 4]));
                                                            break;
                                                        case 4:
                                                            bid_num_p4.setText(String.valueOf(current_tricks.get(winner - 1)) + "/" + String.valueOf(biddings[((winner - 1) + (5 - player_num)) % 4]));
                                                            break;
                                                    }

                                                    roomRef.child("game").child("turn").setValue(winner)
                                                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                @Override
                                                                public void onComplete(@NonNull Task<Void> task) {
                                                                    if (task.isSuccessful()) {
                                                                        cards_images[0].setVisibility(View.INVISIBLE);
                                                                        cards_images[1].setVisibility(View.INVISIBLE);
                                                                        cards_images[2].setVisibility(View.INVISIBLE);

                                                                        ArrayList arraylist = new ArrayList<>();

                                                                        for (int i = 1; i <= 4; i++) {
                                                                            arraylist.add(-1);
                                                                        }
                                                                        roomRef.child("game").child("card_played").setValue(arraylist)
                                                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                                    @Override
                                                                                    public void onComplete(@NonNull Task<Void> task) {
                                                                                        if (task.isSuccessful()) {
                                                                                            if (sortedCards.size() == 0) {
                                                                                                Intent i = new Intent(GameActivity.this, GameStatsActivity.class);

                                                                                                i.putExtra(String.valueOf(room.getUsers().get(0)), calculate_points(current_tricks.get(0), biddings[((1 - 1) + (5 - player_num)) % 4], bidding_sum > 13));
                                                                                                i.putExtra(String.valueOf(room.getUsers().get(1)), calculate_points(current_tricks.get(1), biddings[((2 - 1) + (5 - player_num)) % 4], bidding_sum > 13));
                                                                                                i.putExtra(String.valueOf(room.getUsers().get(2)), calculate_points(current_tricks.get(2), biddings[((3 - 1) + (5 - player_num)) % 4], bidding_sum > 13));
                                                                                                i.putExtra(String.valueOf(room.getUsers().get(3)), calculate_points(current_tricks.get(3), biddings[((4 - 1) + (5 - player_num)) % 4], bidding_sum > 13));

                                                                                                i.putExtra("1", room.getUsers().get(0));
                                                                                                i.putExtra("2", room.getUsers().get(1));
                                                                                                i.putExtra("3", room.getUsers().get(2));
                                                                                                i.putExtra("4", room.getUsers().get(3));

                                                                                                startActivity(i);
                                                                                            }


                                                                                            cards_played_counter = 0;

                                                                                            clicks_not_allowed = false;
                                                                                        } else {

                                                                                        }
                                                                                    }
                                                                                });
                                                                    } else {

                                                                    }
                                                                }
                                                            });
                                                } else {

                                                }
                                            }
                                        });
                            } else {
                                current_tricks.set(winner - 1, current_tricks.get(winner - 1) + 1);

                                switch (((winner - 1) + (5 - player_num)) % 4 + 1) {
                                    case 1:
                                        bid_num_p1.setText(String.valueOf(current_tricks.get(winner - 1)) + "/" + String.valueOf(biddings[((winner - 1) + (5 - player_num)) % 4]));
                                        break;
                                    case 2:
                                        bid_num_p2.setText(String.valueOf(current_tricks.get(winner - 1)) + "/" + String.valueOf(biddings[((winner - 1) + (5 - player_num)) % 4]));
                                        break;
                                    case 3:
                                        bid_num_p3.setText(String.valueOf(current_tricks.get(winner - 1)) + "/" + String.valueOf(biddings[((winner - 1) + (5 - player_num)) % 4]));
                                        break;
                                    case 4:
                                        bid_num_p4.setText(String.valueOf(current_tricks.get(winner - 1)) + "/" + String.valueOf(biddings[((winner - 1) + (5 - player_num)) % 4]));
                                        break;
                                }

                                    cards_images[0].setVisibility(View.INVISIBLE);
                                    cards_images[1].setVisibility(View.INVISIBLE);
                                    cards_images[2].setVisibility(View.INVISIBLE);

                                if (sortedCards.size() == 0) {
                                    Intent i = new Intent(GameActivity.this, GameStatsActivity.class);

                                    i.putExtra(String.valueOf(room.getUsers().get(0)), calculate_points(current_tricks.get(0), biddings[((1 - 1) + (5 - player_num)) % 4], bidding_sum > 13));
                                    i.putExtra(String.valueOf(room.getUsers().get(1)), calculate_points(current_tricks.get(1), biddings[((2 - 1) + (5 - player_num)) % 4], bidding_sum > 13));
                                    i.putExtra(String.valueOf(room.getUsers().get(2)), calculate_points(current_tricks.get(2), biddings[((3 - 1) + (5 - player_num)) % 4], bidding_sum > 13));
                                    i.putExtra(String.valueOf(room.getUsers().get(3)), calculate_points(current_tricks.get(3), biddings[((4 - 1) + (5 - player_num)) % 4], bidding_sum > 13));

                                    i.putExtra("1", room.getUsers().get(0));
                                    i.putExtra("2", room.getUsers().get(1));
                                    i.putExtra("3", room.getUsers().get(2));
                                    i.putExtra("4", room.getUsers().get(3));

                                    startActivity(i);

                                }

                                cards_played_counter = 0;


                                clicks_not_allowed = false;

                            }
                        }
                    }, 2000);






                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        };


        btnBid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (phase == 0) {
                    if (player_num == turn && currentBid > highestBid) {
                        roomRef.child("game").child("turn").setValue(turn % 4 + 1).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    roomRef.child("game").child("biddings").child(String.valueOf(player_num - 1)).setValue(currentBid);
                                    biddings[0] = (int) currentBid;
                                }
                            }
                        });
                    }
                } else {
                    if (player_num == turn) {
                        if (turns_after_bid != 6) {
                            roomRef.child("game").child("turn").setValue(turn % 4 + 1).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        roomRef.child("game").child("biddings").child(String.valueOf(player_num - 1)).setValue(currentBid);
                                        biddings[0] = (int) currentBid;
                                    }
                                }
                            });
                        } else {
                            if (bidding_sum + currentBid != 13) {
                                roomRef.child("game").child("turn").setValue(turn % 4 + 1).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            roomRef.child("game").child("biddings").child(String.valueOf(player_num - 1)).setValue(currentBid);
                                            biddings[0] = (int) currentBid;
                                        }
                                    }
                                });
                            } else {

                            }
                        }
                    }
                }
            }
        });


        btnMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (phase == 0) {
                    if (currentBid > 5) {
                        currentBid = currentBid - 5;
                        bidding_number.setText(Long.toString(5 + ((currentBid - 1) / 5)));
                    }
                } else {
                    if (currentBid > 0) {
                        currentBid = currentBid - 1;
                        bidding_number.setText(Long.toString(currentBid));
                    }
                }

            }
        });

        btnPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (phase == 0) {
                    if (currentBid < 40) {
                        currentBid = currentBid + 5;
                        bidding_number.setText(Long.toString(5 + ((currentBid - 1) / 5)));
                    }
                } else {
                    if (currentBid < 13) {
                        currentBid = currentBid + 1;
                        bidding_number.setText(Long.toString(currentBid));
                    }
                }
            }
        });

        btnClub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentBid = ((currentBid - 1) / 5) * 5 + 1;
            }
        });

        btnSpade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentBid = ((currentBid - 1) / 5) * 5 + 4;
            }
        });

        btnDiamond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentBid = ((currentBid - 1) / 5) * 5 + 2;
            }
        });

        btnHeart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentBid = ((currentBid - 1) / 5) * 5 + 3;
            }
        });

        btnNt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentBid = ((currentBid - 1) / 5) * 5 + 5;
            }
        });

        btnPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (turn == player_num) {

                    if (biddings[0] == highestBid - 1) {
                        roomRef.child("game").child("turn").setValue(turn % 4 + 1).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    roomRef.child("game").child("biddings").child(String.valueOf(player_num - 1)).setValue(highestBid - 2);
                                    biddings[0] = -1;
                                }
                            }
                        });
                    } else {
                        roomRef.child("game").child("turn").setValue(turn % 4 + 1).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    roomRef.child("game").child("biddings").child(String.valueOf(player_num - 1)).setValue(highestBid - 1);
                                    biddings[0] = -1;
                                }
                            }
                        });
                    }
                }



            }
        });

        layout.setOnTouchListener(new View.OnTouchListener() { // handle user clicks (if its their turn and they click on a crad it will update the ui and if they click on it again and they can play it it will play it.
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                if (clicks_not_allowed) {
                    return true;
                }

                if (phase == 2 && turn == player_num) {
                    if (event.getAction() == MotionEvent.ACTION_UP) {
                        float y = event.getY();
                        float x = event.getX();
                        relevant_click = false;

                        card_number = (x + 0.5 * width / 3 * 0.6887 - width / 8) / (usableWidth / number) + 0.5;

                        if ((int) card_number > 0 && y <= height - (height / 25) &&
                                (y >= height - (height / 25) - (width / 3) ||
                                        ((y >= height - (height / 25) - (width / 3) - 50) && clicked_card == (int) card_number))) {

                            relevant_click = true;

                            if (card_number > number) {
                                card_number = number;
                            }

                            if ((int) card_number == clicked_card) {
                                if (hand.canplayCard((int) card_number, needed_suit + 1, cards_played_counter == 0)) {

                                    boolean flag2 = cards_played_counter != 3;

                                    hand.playCard((int) card_number, needed_suit + 1, cards_played_counter == 0);

                                    last_card_played_number = (int) (card_number - 1);

                                    roomRef.child("game").child("card_played").child(String.valueOf(player_num - 1))
                                            .setValue(sortedCards.get(last_card_played_number))
                                            .addOnCompleteListener(task -> {
                                                if (task.isSuccessful()) {
                                                    sortedCards.remove(last_card_played_number);
                                                    layout.getChildAt((int) card_number - 1).setX((int) (width / 2 - 0.5 * width / 3 * 0.6887));
                                                    layout.getChildAt((int) card_number - 1).setY((int) (height / 2 + 0.5 * width / 3));
                                                    cards.remove((int) card_number - 1);
                                                    number--;
                                                    clicked_card = -1;
                                                    update_game(cards, layout, number, 1);

                                                    if (flag2) {
                                                        roomRef.child("game").child("turn").setValue(turn % 4 + 1);
                                                    }
                                                } else {
                                                    System.err.println("Error setting card played: " + task.getException().getMessage());
                                                }
                                            });
                                }





                            } else {
                                if (clicked_card == -1) {
                                    clicked_card = (int) card_number;
                                    layout.getChildAt((int) card_number - 1).setY(layout.getChildAt((int) card_number - 1).getY() - 50);

                                } else {
                                    layout.getChildAt(clicked_card - 1).setY(layout.getChildAt(clicked_card - 1).getY() + 50);
                                    clicked_card = (int) card_number;
                                    layout.getChildAt((int) card_number - 1).setY(layout.getChildAt((int) card_number - 1).getY() - 50);

                                }
                            }
                        }
                        if (relevant_click == false) {
                            if (clicked_card != -1) {
                                layout.getChildAt(clicked_card - 1).setY(layout.getChildAt(clicked_card - 1).getY() + 50);
                            }
                            clicked_card = -1;
                        }


                        return true;
                    }

                }
                return true;
            }

        });
    }

    public int[] update_game(ArrayList<ImageView> cards, ConstraintLayout layout, int number, int player_num) { //1 = main, 2 = next(by clock rotation... ) gets ArrayList<ImageView> cards, ConstraintLayout layout, int number, int player_num and returns the coords of the main hand cards or null based on the function it runs, it also runs the correct update function based on what it gets


        switch (player_num) {
            case 1:
                return update_main_hand(cards, layout, number);
            case 2:
                update_side_hands(layout, number, 2);
                return null;
            case 3:
                update_up_hand(layout, number);
                return null;
            case 4:
                update_side_hands(layout, number, 4);
                return null;
        }


        return null;

    }

    public int[] update_main_hand(ArrayList<ImageView> cards, ConstraintLayout layout, int number) { //gets ArrayList<ImageView> cards, ConstraintLayout layout, int number and update the main hand while returning the coords of the cards (unused returning)


        DisplayMetrics display = getResources().getDisplayMetrics();
        int height = display.heightPixels;
        int width = display.widthPixels;
        int usableWidth = width - width / 4;

        int[] positions = new int[number];

        ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams((int) (width / 3 * 0.6887), width / 3);

        for (int i = 0; i < number; i++) {


            float x = (float) ((usableWidth / number) * (i + 0.5) - (0.5 * params.width) + (width / 8));
            cards.get(i).setX(x);
            cards.get(i).setY(height - height / 25 - params.height);
            cards.get(i).setLayoutParams(params);

            if (number == 13)
                layout.addView(cards.get(i));

            positions[i] = (int) (x);
        }
        return null;
    }

    public void update_side_hands(ConstraintLayout layout, int number, int player_num) { //gets ConstraintLayout layout, int number, int player_num and update the hand of the player_num index player

        DisplayMetrics display = getResources().getDisplayMetrics();
        int height = display.heightPixels;
        int width = display.widthPixels;


        ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams((int) (width / 3 * 0.7125), width / 3);

        ImageView[] back_cards = new ImageView[number];

        for (int i = 0; i < number; i++) {

            back_cards[i] = new ImageView(this);
            back_cards[i].setImageResource(R.drawable.card_back);
            back_cards[i].setBackgroundTintMode(null);

            int usableHeight = (params.width / 5) * (number - 1) + params.width;

            float y = (float) ((i) * (params.width / 5) + (height - usableHeight) / 3);

            if (player_num == 2) {
                back_cards[i].setX((float) (params.height / 3 * 2 * (-1) + (params.height / 6.8)));


            } else {
                back_cards[i].setX((float) (width - ((-1) * (params.height / 3 * 2 - params.height)) + (params.height / 6.8)));


            }
            back_cards[i].setY(y);
            back_cards[i].setLayoutParams(params);
            back_cards[i].setRotation(90);
            layout.addView(back_cards[i]);

        }
    }

    public void update_up_hand(ConstraintLayout layout, int number) { // gets ConstraintLayout layout, int number and updates the hand of the player with index 3 (index means player 3 from this players point of view)

        DisplayMetrics display = getResources().getDisplayMetrics();

        int width = display.widthPixels;
        ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams((int) (width / 3 * 0.7125), width / 3);

        int usableWidth = (params.width / 5) * (number - 1) + params.width;

        ImageView[] back_cards = new ImageView[number];


        for (int i = 0; i < number; i++) {
            back_cards[i] = new ImageView(this);
            back_cards[i].setImageResource(R.drawable.card_back);
            back_cards[i].setBackgroundTintMode(null);

            float x = (float) ((i) * (params.width / 5) + (width - usableWidth) / 2);

            back_cards[i].setX(x);

            back_cards[i].setY(params.height / 3 * 2 * (-1));

            back_cards[i].setLayoutParams(params);

            layout.addView(back_cards[i]);


        }
    }


    public static int round_winner(int turn, int suit, DataSnapshot snapshot, ConstraintLayout layout, int last_card_played_number) { // gets int turn, int suit, DataSnapshot snapshot, ConstraintLayout layout, int last_card_played_number and sremoves a card from he layout and setting last_card_played_number to -1 and returns the number of the winner of the round

        HashMap<Integer, Integer> turns = new HashMap<>();
        turns.put(1, 4);
        turns.put(2, 1);
        turns.put(3, 2);
        turns.put(4, 3);


        layout.removeViewAt(last_card_played_number);

        last_card_played_number = -1;


        int size = 4;

        ArrayList<Long> cards = (ArrayList<Long>) (snapshot.getValue());



        ArrayList<Long> cards1 = (ArrayList<Long>) cards.clone();
        ArrayList<Long> cards_saver = (ArrayList<Long>) cards.clone();


        long played_suit = (cards.get(turn % 4) % 4); //0 = club, 1 = diamond, 2 = heart, 3 = spade


        if (suit != 5) {


            for (int i = 0; i < size; i++) {
                if (cards.get(i - (size - cards.size())) % 4 != suit - 1) {
                    cards1.remove(i - (size - cards1.size()));
                }
            }

            if (cards1.size() == 1) {

                return cards_saver.indexOf(cards1.get(0)) + 1;
            }


            if (cards1.size() == 0) {
                cards1 = (ArrayList<Long>) cards.clone();
            } else {
                cards = (ArrayList<Long>) cards1.clone();
            }

            size = cards1.size();
        }
        for (int i = 0; i < size; i++) {
            if (cards.get(i - (size - cards.size())) % 4 != played_suit) {
                cards1.remove(i - (size - cards1.size()));
            }
        }

        if (cards1.size() == 0) {
            cards1 = (ArrayList<Long>) cards.clone();
        }

        Collections.sort(cards1);
        return cards_saver.indexOf(cards1.get(cards1.size() - 1)) + 1;


    }

    public static int calculate_points(int tricks, int bid, boolean over) { // gets int tricks, int bid, boolean over and return the points the player got

        if (tricks == bid) {

            if (bid == 0) {
                if (over) {
                    return 25;
                } else {
                    return 50;
                }
            } else {
                return bid * bid + 10;
            }
        } else {
            if (bid == 0) {
                return tricks * 10 - 50;
            }
            if (tricks > bid) {
                return (tricks - bid) * -10;
            } else {
                return (bid - tricks) * -10;
            }
        }
    }

    public void startMusic() {
        startService(musicIntent);
    } //plays sound

    public void onBackPressed() { //prevent clicks on the back button of the phone

    }
}