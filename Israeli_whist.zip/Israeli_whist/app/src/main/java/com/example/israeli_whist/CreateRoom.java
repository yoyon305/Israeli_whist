package com.example.israeli_whist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;

import org.checkerframework.checker.units.qual.C;

import java.util.ArrayList;

public class CreateRoom extends AppCompatActivity {


    private FirebaseAuth auth;
    private TextView[] players_text;
    private Button btnId;
    private Button btnStart, btnBack;
    private DatabaseReference newRoomRef;
    private ValueEventListener listener;
    private ArrayList<String> users;
    private Intent musicIntent;

    private CountDownTimer cTimer;
    private Context context;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_room);

        FirebaseApp.initializeApp(this);

        musicIntent = new Intent(this, MusicService.class);


        auth = FirebaseAuth.getInstance();
        players_text = new TextView[4];
        players_text[0] = findViewById(R.id.txtPlayer1);
        players_text[1] = findViewById(R.id.txtPlayer2);
        players_text[2] = findViewById(R.id.txtPlayer3);
        players_text[3] = findViewById(R.id.txtPlayer4);
        btnId = findViewById(R.id.btnId);
        btnStart = findViewById(R.id.btnStart);
        btnBack = findViewById(R.id.btnBack);
        users = new ArrayList<>();

        context = this;

        cTimer = null;

        FirebaseDatabase database = FirebaseDatabase.getInstance("https://israeli-whist-aae67-default-rtdb.europe-west1.firebasedatabase.app/");
        DatabaseReference roomsRef = database.getReference("Rooms");


        Room room = new Room(auth.getCurrentUser().getEmail().substring(0, auth.getCurrentUser().getEmail().length() - 10));

        newRoomRef = roomsRef.push();
        room.setId(newRoomRef.getKey());
        newRoomRef.setValue(room);
        btnId.setText("id: " + newRoomRef.getKey());
        players_text[0].setText("player 1: " + auth.getCurrentUser().getEmail().substring(0, auth.getCurrentUser().getEmail().length() - 10));

        newRoomRef = database.getReference("Rooms").child(room.getId()).child("users");

        startMusic();

        btnStart.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {


                if (room.getUsers().size() == 4){

                    room.getGame().setTurn(1);
                    database.getReference("Rooms").child(room.getId()).child("game").child("turn").setValue(1);

                    Intent i = new Intent(CreateRoom.this, GameActivity.class);
                    i.putExtra("id", room.getId());
                    i.putExtra("player_num", users.indexOf(auth.getCurrentUser().getEmail().substring(0, auth.getCurrentUser().getEmail().length() - 10)) + 1);

                    cancelTimer();

                    startActivity(i);
                } else {
                    Toast.makeText(CreateRoom.this, "cant start the game without 4 players", Toast.LENGTH_SHORT).show();
                }

            }
        });

        btnId.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {


                ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);


                ClipData clip = ClipData.newPlainText("Copied Text", room.getId());


                clipboard.setPrimaryClip(clip);

                Toast.makeText(context, "Text copied to clipboard", Toast.LENGTH_SHORT).show();

            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                newRoomRef.removeEventListener(listener);
                database.getReference("Rooms").child(room.getId()).removeValue();

                Intent i = new Intent(CreateRoom.this, MainActivity.class);
                startActivity(i);

            }
        });

        //newRoomRef.addValueEventListener(new ValueEventListener() {
        listener = new ValueEventListener(){
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                cancelTimer();

                users = (ArrayList<String>)dataSnapshot.getValue();
                room.setUsers(users);

                for (int i = 1; i < room.getUsers().size(); i++){
                    players_text[i].setText("player " + (i + 1) + ": " + room.getUsers().get(i));
                }

                for (int i = room.getUsers().size(); i < 4; i++){
                    players_text[i].setText("player " + (i + 1) + ": ");
                }

                if (users.size() == 4){
                    startTimer(30);


                }
                startMusic();
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        };
        newRoomRef.addValueEventListener(listener);
    }

    public void startMusic() {
        startService(musicIntent);
    } //plays sound



    void startTimer(int intervalInput) { // gets number of seconds and starts a timer, if the timer will finish, it will show a toast that will remind the creator to starty the game and start it again
        cTimer = new CountDownTimer(intervalInput*1000, 1000) {

            public void onTick(long millisUntilFinished) {
            }
            public void onFinish() {
                //startTimer(intervalInput);
                Toast.makeText(CreateRoom.this, "everyone are waiting for you to start the game", Toast.LENGTH_SHORT).show();
                startTimer(30);
            }
        };
        cTimer.start();




    }

    void cancelTimer() {// cancel the timer
        if(cTimer!=null)
            cTimer.cancel();
    }
}