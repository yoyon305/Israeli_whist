package com.example.israeli_whist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Login extends AppCompatActivity {

    private TextView txt_login;
    private EditText email;
    private EditText password;
    private Button login;
    private Intent intent;
    private FirebaseAuth auth;

// this activity is the login activity, it asks the user to enter email and password, if its correct it log in, if no and the mail is correct it signs up, else it woll not sign in.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        FirebaseApp.initializeApp(this);


        auth = FirebaseAuth.getInstance();

        if (auth.getCurrentUser() != null){
            intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }

        txt_login = findViewById(R.id.login);
        email = findViewById(R.id.editTextEmail);
        password = findViewById(R.id.editTextTextPassword);
        login = findViewById(R.id.btnlogin);
        intent = new Intent(this, MainActivity.class);
        FirebaseApp.initializeApp(this);


    }


    public void onClick(View view) {
        if (view.getId() == R.id.btnlogin) {


            auth.createUserWithEmailAndPassword(email.getText().toString(), password.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        Toast.makeText(Login.this, "Signup Successful", Toast.LENGTH_SHORT).show();

                        startActivity(new Intent(Login.this, MainActivity.class));
                    } else{
                        auth.signInWithEmailAndPassword(email.getText().toString(), password.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isSuccessful()){
                                    Toast.makeText(Login.this, "Login Successful", Toast.LENGTH_SHORT).show();

                                    startActivity(new Intent(Login.this, MainActivity.class));
                                } else{
                                    Toast.makeText(Login.this, "Login Failed" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                }
            });
        }
    }
}

