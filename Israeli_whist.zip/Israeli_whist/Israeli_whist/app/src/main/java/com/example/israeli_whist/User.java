package com.example.israeli_whist;
import android.content.Context;

import androidx.annotation.Nullable;

public class User {
    private int id;
    private String email;
    private String pass;


    public User() {
    }




    public User(int id, String email, String pass) {
        this.id = id;
        this.email = email;
        this.pass = pass;
    }

    public User(String email, String pass) {
        this.email = email;
        this.pass = pass;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPass() {
        return this.pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    @Override
    public String toString() {
        return "User:\t" + this.id + ", " + this.email + ", " + this.pass;
    }
}
