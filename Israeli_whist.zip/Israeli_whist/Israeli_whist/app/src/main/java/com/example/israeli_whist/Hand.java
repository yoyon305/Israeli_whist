package com.example.israeli_whist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;


public class Hand {

    //private ArrayList<Card> cards;
    HashMap<Integer, ArrayList<Integer>> hand;


    public Hand(int[][] cards){ //[suit][number]


        hand = new HashMap<>();
        for (int i = 1; i <= 4; i++){
            hand.put(i, new ArrayList<Integer>());

        }

        for (int i = 0; i < 13; i++){
            hand.get(cards[i][0]).add(cards[i][1]);
        }

        for (int i = 1; i <= 4; i++){
            Collections.sort(hand.get(i));
        }
    }

    public ArrayList<Integer> getSuitCards(int suit){

        return hand.get(suit);
    }
    public int[] playCard(int index, int requiredSuit, boolean my_turn){



        if (my_turn || hand.get(requiredSuit).size() == 0){
            for(int i = 1; i <= 4; i++){
                if (index <= hand.get(i).size()){
                    int[] card = new int[2];
                    card[0] = i;
                    card[1] = hand.get(i).get(index - 1);
                    hand.get(i).remove(index - 1);
                    return card;
                }
                index -= hand.get(i).size();
            }
        }
        else {
            for(int i = 1; i <= 4; i++){
                if (index <= hand.get(i).size()){
                    if (i != requiredSuit){
                        return null;
                    }
                    int[] card = new int[2];
                    card[0] = i;
                    card[1] = hand.get(i).get(index - 1);
                    hand.get(i).remove(index - 1);
                    return card;
                }
                index -= hand.get(i).size();
            }

        }
        return null;
    }

    public int[][] getCards(){

        int[][] cards = new int[13][2];
        int counter = 0;
        //System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 2 " + hand.get(1).toString() + hand.get(2).toString()+ hand.get(3).toString()+ hand.get(4).toString());

        for (int i = 1; i <= 4; i++){
            int size =  hand.get(i).size();
            for (int j = 0; j < size; j++) {
                cards[counter][0] = i; //suit
                cards[counter][1] = hand.get(i).get(j); // number
                counter++;
            }
        }
        return cards;
    }




}
