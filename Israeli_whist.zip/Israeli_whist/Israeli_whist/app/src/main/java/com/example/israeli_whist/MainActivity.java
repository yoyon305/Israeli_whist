package com.example.israeli_whist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private int number;

    private ConstraintLayout layout;

    private ArrayList<ImageView> cards; //player 1 hand images

    private Hand hand; //player 1 hand

    private String[] suits; // spades, hearts, diamonds, clubs

    private String[] numbers;

    private int[][][] hands; //holds the 4 hands cards

    private int[][] sortedCards;

    private int clicked_card;

    private boolean relevant_click, bidding_phase;

    private int last_card_played_number;

    private TextView bidding_number, bid_num_p1, bid_num_p2, bid_num_p3, bid_num_p4;

    private ImageView btnsymbol1, btnsymbol2, btnsymbol3, btnsymbol4;
    private Button btnPlus, btnMinus, btnSpade, btnHeart, btnClub, btnDiamond, btnNt, btnBid, btnPass;

    private int[][] biddings; //player, (number, suit)

    private int[] currentBid; //number, suit











    private FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        bidding_number = new TextView(this);
        bid_num_p1 = new TextView(this);
        bid_num_p2 = new TextView(this);
        bid_num_p3 = new TextView(this);
        bid_num_p4 = new TextView(this);
        btnPlus = new Button(this);
        btnMinus = new Button(this);
        btnSpade = new Button(this);
        btnHeart = new Button(this);
        btnDiamond = new Button(this);
        btnClub = new Button(this);
        btnNt = new Button(this);
        btnBid = new Button(this);
        btnPass = new Button(this);

        btnsymbol1 = new ImageView(this);
        btnsymbol2 = new ImageView(this);
        btnsymbol3 = new ImageView(this);
        btnsymbol4 = new ImageView(this);


        currentBid = new int[2];

        currentBid[0] = 5;
        currentBid[1] = -1;

        biddings = new int[4][2];

        bidding_phase = true;


        layout = findViewById(R.id.layout);

        suits = new String[]{"spades", "hearts", "clubs", "diamonds" };
        numbers = new String[]{"two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "jack", "queen", "king", "ace"};


        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);


        DisplayMetrics display = getResources().getDisplayMetrics();
        int height = display.heightPixels;
        int width = display.widthPixels;
        int usableWidth = width - width / 4;

        clicked_card = -1;
        relevant_click = false;
        last_card_played_number = -1;

        hands = shuffle();
        hand = new Hand(hands[0]); //player 1
        sortedCards = hand.getCards();

        cards = new ArrayList<>();
        for (int i = 0; i < 13; i++) {
            cards.add(new ImageView(this));
            //System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 1 " + sortedCards[i][0]);

            String card_name = numbers[sortedCards[i][1]] + "_of_" + suits[sortedCards[i][0] - 1];
            int resourceId = getResources().getIdentifier(card_name, "drawable", getPackageName());
            cards.get(i).setImageResource(resourceId);
        }
        number = 13;
        int[] positions = update_game(cards, layout, number, 1);
        update_game(null, layout, 13, 3);
        update_game(null, layout, 13, 2);
        update_game(null, layout, 13, 4);


        ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams((int) (width / 4), height / 14);


        btnPass.setX((float)(width / 2 - 0.5 * params.width - params.width * 0.6));
        btnPass.setY((float)(height / 2));
        btnPass.setText("pass");
        btnPass.setBackgroundColor(Color.rgb(220,220,220));
        btnPass.setLayoutParams(params);
        btnPass.setTextSize(24);


        btnBid.setX((float)(width / 2 - 0.5 * params.width + params.width * 0.6));
        btnBid.setY((float)(height / 2));
        btnBid.setText("bid");
        btnBid.setBackgroundColor(Color.rgb(220,220,220));
        btnBid.setLayoutParams(params);
        btnBid.setTextSize(24);

        bidding_number.setX((float)(width / 2 - 0.5 * params.width));
        bidding_number.setY((float)(height / 2.4));
        bidding_number.setText(Integer.toString(currentBid[0]));
        bidding_number.setBackgroundColor(Color.rgb(220,220,220));
        bidding_number.setTextColor(Color.BLACK);
        bidding_number.setTextSize(24);
        bidding_number.setLayoutParams(params);
        bidding_number.setGravity(Gravity.CENTER);

        params = new ConstraintLayout.LayoutParams((int) (width / 8), height / 17);

        btnPlus.setX((float)(width - (width / 3.5) - 0.5 * params.width));
        btnPlus.setY((float)(height / 2.4 + ((height / 14 - height / 17) / 2)));
        btnPlus.setText("+");
        btnPlus.setBackgroundColor(Color.rgb(220,220,220));
        btnPlus.setLayoutParams(params);
        btnPlus.setTextSize(20);



        btnMinus.setX((float)(width / 3.5 - 0.5 * params.width));
        btnMinus.setY((float)(height / 2.4 + ((height / 14 - height / 17) / 2)));
        btnMinus.setText("-");
        btnMinus.setBackgroundColor(Color.rgb(220,220,220));
        btnMinus.setLayoutParams(params);
        btnMinus.setTextSize(24);





        btnSpade.setX((float)(width / 2 - 0.5 * params.width - (width / 2 - 0.5 * params.width - (width / 3.5 - 0.5 * params.width)) / 2));
        btnSpade.setY((float)(height / 2 + (height / 2 - height / 2.4) * 2  + 0.25 * params.height) );
        btnSpade.setBackgroundResource(R.drawable.spade);
        btnSpade.setLayoutParams(params);

        btnDiamond.setX((float)(width / 2 - 0.5 * params.width));
        btnDiamond.setY((float)(height / 2 + (height / 2 - height / 2.4) + 0.25 * params.height));
        btnDiamond.setBackgroundResource(R.drawable.diamond);
        btnDiamond.setLayoutParams(params);


        btnClub.setX((float)(width / 3.5 - 0.5 * params.width));
        btnClub.setY((float)(height / 2 + (height / 2 - height / 2.4) + 0.25 * params.height));
        btnClub.setBackgroundResource(R.drawable.club);
        btnClub.setLayoutParams(params);

        btnHeart.setX((float)(width - (width / 3.5) - 0.5 * params.width));
        btnHeart.setY((float)(height / 2 + (height / 2 - height / 2.4) + 0.25 * params.height));
        btnHeart.setBackgroundResource(R.drawable.heart);
        btnHeart.setLayoutParams(params);

        btnNt.setX((float)(width / 2 - 0.5 * params.width + (width / 2 - 0.5 * params.width - (width / 3.5 - 0.5 * params.width)) / 2));
        btnNt.setY((float)(height / 2 + (height / 2 - height / 2.4) * 2  + 0.25 * params.height) );
        btnNt.setLayoutParams(params);
        btnNt.setTextSize(20);
        btnNt.setText("NT");
        btnNt.setBackgroundColor(Color.rgb(20,80,13));


        bid_num_p1.setText("8");
        bid_num_p1.setTextSize(35);
        bid_num_p1.setX((float)(width / 2 - 0.5 * params.width));
        bid_num_p1.setY((float)(height / 3));
        bid_num_p1.setLayoutParams(params);
        bid_num_p1.setTextColor(Color.BLACK);

        bid_num_p2.setText("8");
        bid_num_p2.setTextSize(35);
        bid_num_p2.setX((float)(width / 4 - 0.5 * params.width));
        bid_num_p2.setY((float)(height / 4.5));
        bid_num_p2.setLayoutParams(params);
        bid_num_p2.setTextColor(Color.BLACK);

        bid_num_p3.setText("8");
        bid_num_p3.setTextSize(35);
        bid_num_p3.setX((float)(width / 2 - 0.5 * params.width));
        bid_num_p3.setY((float)(height / 10));
        bid_num_p3.setLayoutParams(params);
        bid_num_p3.setTextColor(Color.BLACK);

        bid_num_p4.setText("8");
        bid_num_p4.setTextSize(35);
        bid_num_p4.setX((float)(width - (width / 4) - params.width / 2));
        bid_num_p4.setY((float)(height / 4.5));
        bid_num_p4.setLayoutParams(params);
        bid_num_p4.setTextColor(Color.BLACK);

        btnsymbol1.setImageResource(R.drawable.diamond);
        btnsymbol1.setX((float)(width / 2 - 0.5 * params.width + params.width * 0.3));
        btnsymbol1.setY(height / 3);
        btnsymbol1.setLayoutParams(params);

        btnsymbol2.setImageResource(R.drawable.club);
        btnsymbol2.setX((float)(width / 4 - 0.5 * params.width + 0.3 * params.width));
        btnsymbol2.setY((float)(height / 4.5));
        btnsymbol2.setLayoutParams(params);

        btnsymbol3.setImageResource(R.drawable.spade);
        btnsymbol3.setX((float)(width / 2 - 0.5 * params.width + params.width * 0.3));
        btnsymbol3.setY((float)(height / 10));
        btnsymbol3.setLayoutParams(params);

        btnsymbol4.setImageResource(R.drawable.heart);
        btnsymbol4.setX((float)(width - (width / 4) - params.width / 2 + params.width * 0.3));
        btnsymbol4.setY((float)(height / 4.5));
        btnsymbol4.setLayoutParams(params);







        layout.addView(btnBid);
        layout.addView(bidding_number);
        layout.addView(btnMinus);
        layout.addView(btnPlus);
        layout.addView(btnClub);
        layout.addView(btnSpade);
        layout.addView(btnDiamond);
        layout.addView(btnHeart);
        layout.addView(btnNt);
        layout.addView(btnPass);
        layout.addView(bid_num_p1);
        layout.addView(bid_num_p2);
        layout.addView(bid_num_p3);
        layout.addView(bid_num_p4);
        layout.addView(btnsymbol1);
        layout.addView(btnsymbol2);
        layout.addView(btnsymbol3);
        layout.addView(btnsymbol4);




        btnBid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentBid[0] != -1 && currentBid[1] != -1){
                    boolean can_bid = true;

                    for (int i = 0; i < 3; i++){
                       if (biddings[3 - i][0] != -1){
                           if (biddings[i][0] < currentBid[0] || (biddings[i][0] == currentBid[0] && biddings[i][1] < currentBid[1])) {

                           } else {
                               can_bid = false;
                           }
                           i = 3; //break
                       }
                   }
                    if (can_bid){
                        biddings[0][0] = currentBid[0];
                        biddings[0][1] = currentBid[1];
                        bidding_phase = false;

                        layout.removeView(btnBid);
                        layout.removeView(bidding_number);
                        layout.removeView(btnMinus);
                        layout.removeView(btnPlus);
                        layout.removeView(btnClub);
                        layout.removeView(btnSpade);
                        layout.removeView(btnDiamond);
                        layout.removeView(btnHeart);
                        layout.removeView(btnNt);
                        layout.removeView(btnPass);
                        layout.removeView(bid_num_p1);
                        layout.removeView(bid_num_p2);
                        layout.removeView(bid_num_p3);
                        layout.removeView(bid_num_p4);
                        layout.removeView(btnsymbol1);
                        layout.removeView(btnsymbol2);
                        layout.removeView(btnsymbol3);
                        layout.removeView(btnsymbol4);

                        btnBid = null;
                        bidding_number = null;
                        btnMinus = null;
                        btnClub = null;
                        btnDiamond = null;
                        btnHeart = null;
                        btnNt = null;
                        btnPass = null;
                        bid_num_p1 = null;
                        bid_num_p2 = null;
                        bid_num_p3 = null;
                        bid_num_p4 = null;
                        btnsymbol1 = null;
                        btnsymbol2 = null;
                        btnsymbol3 = null;
                        btnsymbol4 = null;

                        layout.invalidate();


                    }
                }
            }
        });

        btnMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentBid[0] > 5) {
                    currentBid[0]--;
                    bidding_number.setText(Integer.toString(currentBid[0]));
                }
            }
        });

        btnPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentBid[0] < 13) {
                    currentBid[0]++;
                    bidding_number.setText(Integer.toString(currentBid[0]));
                }
            }
        });

        btnClub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentBid[1] = 0;
            }
        });

        btnSpade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentBid[1] = 3;
            }
        });

        btnDiamond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentBid[1] = 1;
            }
        });

        btnHeart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentBid[1] = 2;
            }
        });

        btnNt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentBid[1] = 4;
            }
        });

        btnPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                biddings[0][0] = -1;
                biddings[0][1] = -1;

            }
        });











        layout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (!bidding_phase) {
                    if (event.getAction() == MotionEvent.ACTION_UP) {
                        float y = event.getY();
                        float x = event.getX();
                        relevant_click = false;

                        //int card_number  = ((int) (x / (((usableWidth / number) * (0.5) - (0.5 * width / 3 * 0.6887) + (width / 8))))) ;
                        //double card_number = ((double) ((double) (x / (((usableWidth / number) - (0.5 * width / 3 * 0.6887) + (width / 8)))) + 0.5));
                        //card_number = card_number + (0.175 * (card_number - 1));
                        double card_number = (x + 0.5 * width / 3 * 0.6887 - width / 8) / (usableWidth / number) + 0.5;
                        //System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa " + card_number);


//&& (int)card_number <= number vvvvvvvvvvv supposed to be in the if
                        if ((int) card_number > 0 && y <= height - (height / 25) && (y >= height - (height / 25) - (width / 3) || ((y >= height - (height / 25) - (width / 3) - 50) && clicked_card == (int) card_number))) {
                            relevant_click = true;
                            //this will be replaced once firebase is coded, so this will be when the round is over and not here
                            if (last_card_played_number != -1) {
                                layout.removeViewAt(last_card_played_number);
                                last_card_played_number = -1;
                            }


                            if (card_number > number)
                                card_number = number;
                            if ((int) card_number == clicked_card) {
                                if (hand.playCard((int) card_number, 1, false) != null) {
                                    //layout.removeAllViews();
                                    //layout.removeViewAt((int) card_number - 1);
                                    layout.getChildAt((int) card_number - 1).setX((int) (width / 2 - 0.5 * width / 3 * 0.6887));
                                    layout.getChildAt((int) card_number - 1).setY((int) (height / 2 + 0.5 * width / 3));
                                    cards.remove((int) card_number - 1);
                                    number--;
                                    last_card_played_number = (int) (card_number - 1);
                                    clicked_card = -1;
                                    update_game(cards, layout, number, 1);
                                }
                            } else {
                                if (clicked_card == -1) {
                                    clicked_card = (int) card_number;
                                    layout.getChildAt((int) card_number - 1).setY(layout.getChildAt((int) card_number - 1).getY() - 50);
                                } else {
                                    layout.getChildAt(clicked_card - 1).setY(layout.getChildAt(clicked_card - 1).getY() + 50);
                                    clicked_card = (int) card_number;
                                    layout.getChildAt((int) card_number - 1).setY(layout.getChildAt((int) card_number - 1).getY() - 50);

                                }
                            }
                        }
                        if (relevant_click == false) {
                            if (clicked_card != -1) {
                                layout.getChildAt(clicked_card - 1).setY(layout.getChildAt(clicked_card - 1).getY() + 50);
                            }
                            clicked_card = -1;
                        }

                        //System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa " + layout.getChildCount());

                        // Do what you want
                        return true;
                    }

                }
                return true;
            }

        });
    }

    public int[] update_game(ArrayList<ImageView> cards, ConstraintLayout layout, int number, int player_num) { //1 = main, 2 = next(by clock rotation... 5 = all)


        switch(player_num) {
            case 1:
                return update_main_hand(cards, layout, number);
            case 2:
                update_side_hands(layout, number, 2);
                return null;
            case 3:
                update_up_hand(layout, number);
                return null;
            case 4:
                update_side_hands(layout, number, 4);
                return null;
        }


        return null;

    }
    public int[] update_main_hand(ArrayList<ImageView> cards, ConstraintLayout layout, int number) {


        DisplayMetrics display = getResources().getDisplayMetrics();
        int height = display.heightPixels;
        int width = display.widthPixels;
        int usableWidth = width - width / 4;

        int[] positions = new int[number];

        ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams((int) (width / 3 * 0.6887), width / 3);

        for (int i = 0; i < number; i++) {

            //image.setX(width / 26 + width / 400);
            //image.setX((float)((width / number) * (i)));
            float x = (float) ((usableWidth / number) * (i + 0.5) - (0.5 * params.width) + (width / 8));
            cards.get(i).setX(x);
            cards.get(i).setY(height - height / 25 - params.height);
            cards.get(i).setLayoutParams(params);

            if (number == 13)
                layout.addView(cards.get(i));

            positions[i] = (int) (x);
        }
        return null;
    }

    public void update_side_hands(ConstraintLayout layout, int number, int player_num) {

        DisplayMetrics display = getResources().getDisplayMetrics();
        int height = display.heightPixels;
        int width = display.widthPixels;
        int usableWidth = width - width / 4;

        //int[] positions = new int[number];

        ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams((int) (width / 3 * 0.7125), width / 3);

        ImageView[] back_cards = new ImageView[number];

        for (int i = 0; i < number; i++) {

            back_cards[i] = new ImageView(this);
            back_cards[i].setImageResource(R.drawable.card_back);
            back_cards[i].setBackgroundTintMode(null);

            //image.setX(width / 26 + width / 400);
            //image.setX((float)((width / number) * (i)));
            int usableHeight = (params.width / 5) * (number - 1) + params.width;

            float y = (float) ((i) * (params.width / 5) + (height - usableHeight) / 3);

            if (player_num == 2) {
                back_cards[i].setX((float) (params.height / 3 * 2 * (-1) + (params.height / 6.8)));
                //back_cards[i].setX((float) (params.height / 6.8));

            } else {
                back_cards[i].setX((float) (width - ((-1) * (params.height / 3 * 2 - params.height)) + (params.height / 6.8)));
                //back_cards[i].setX((float)(width + (params.height / 6.8)));

            }
            back_cards[i].setY(y);
            back_cards[i].setLayoutParams(params);
            back_cards[i].setRotation(90);
            layout.addView(back_cards[i]);

            //positions[i] = (int) (x);
        }
    }

    public void update_up_hand(ConstraintLayout layout, int number) {

        DisplayMetrics display = getResources().getDisplayMetrics();
        //int height = display.heightPixels;
        int width = display.widthPixels;
        ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams((int) (width / 3 * 0.7125), width / 3);

        int usableWidth = (params.width / 5) * (number - 1) + params.width;

        //int[] positions = new int[number];

        ImageView[] back_cards = new ImageView[number];


        for (int i = 0; i < number; i++) {
            back_cards[i] = new ImageView(this);
            back_cards[i].setImageResource(R.drawable.card_back);
            back_cards[i].setBackgroundTintMode(null);




            float x = (float) ((i) * (params.width / 5) + (width - usableWidth) / 2);

            back_cards[i].setX(x);
            //back_cards[i].setY(params.height / 3 * 2 * (-1));
            //back_cards[i].setX(0);
            back_cards[i].setY(params.height / 3 * 2 * (-1));


            back_cards[i].setLayoutParams(params);

            layout.addView(back_cards[i]);

            //positions[i] = (int) (x);
        }
    }







        public static int[][][] shuffle() { // [player][suit][number]

        HashMap<Integer, ArrayList<Integer>> cards = new HashMap<>();

        for (int k = 1; k <= 4; k++) {
            cards.put(k, new ArrayList<Integer>());
        }

        for (int i = 1; i <= 4; i++) {
            for (int j = 0; j < 13; j++) {
                 cards.get(i).add(j);
            }
        }
        int[][][] hands = new int[4][13][2];
        Random rand = new Random();
        int suit = rand.nextInt(4) + 1;
        int number;

        for (int b = 0; b < 4; b++) {
            for (int c = 0; c < 13; c++) {

                while ( cards.get(suit).size() == 0) {
                    suit = rand.nextInt(4) + 1;
                }
                //System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa 1 " + cards.get(suit).size());

                number = rand.nextInt(cards.get(suit).size());
                hands[b][c][0] = suit;
                hands[b][c][1] =  cards.get(suit).get(number);

                cards.get(suit).remove(number);
                suit = rand.nextInt(4) + 1;
            }

        }
        return hands;
    }

}


