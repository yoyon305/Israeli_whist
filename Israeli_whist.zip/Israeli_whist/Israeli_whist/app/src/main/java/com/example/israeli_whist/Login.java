package com.example.israeli_whist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {

    private TextView txt_login;
    private EditText email;
    private EditText password;
    private Button login;
    private Intent intent;
   // private FirebaseApp helper;
    private User user;

    private FirebaseAuth auth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        FirebaseApp.initializeApp(this);

        auth = FirebaseAuth.getInstance();

        //auth.createUserWithEmailAndPassword(email, password);



// Get a reference to a specific location in the database
        //DatabaseReference myRef = database.getReference("path/to/your/data");

        txt_login = findViewById(R.id.login);
        email = findViewById(R.id.editTextEmail);
        password = findViewById(R.id.editTextTextPassword);
        login = findViewById(R.id.btnlogin);
        intent = new Intent(this, MainActivity.class);



    }

    public void onClick(View view) {
        if (view.getId() == R.id.btnlogin) {


            auth.createUserWithEmailAndPassword(email.getText().toString(), password.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        Toast.makeText(Login.this, "Signup Successful", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Login.this, MainActivity.class));
                    } else{
                        auth.signInWithEmailAndPassword(email.getText().toString(), password.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isSuccessful()){
                                    Toast.makeText(Login.this, "Login Successful", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(Login.this, MainActivity.class));
                                } else{
                                    Toast.makeText(Login.this, "Login Failed" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                }
            });


        }
    }
    //AlertDialog dialog = alertdialog.create();
    //alertdialog.show();

    //toast = Toast.makeText(getApplicationContext(), "wrong password", Toast.LENGTH_SHORT);
    //toast.show();

}

//login- if the user exists, login, if no, ask if you want to create it, if the input is invalid' toast it up and return to the main login